import { Component, ViewChild } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FooternavComponent } from './Components/footernav/footernav.component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'DeliveryApp';

  
}